﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL1
{
    public class KarbarManagement : SqlClass
    {
        linqDataContext obj = new linqDataContext();
        protected void KarbarInsert2(KarbarDB db)
        {
            obj.KarbarInsert(db.IDKarbar, db.UserName, db.Password, db.NameKarbar, db.FamilyKarbar, db.Semat, db.Madrak, db.CodeMeli, db.TarikheTavalod, db.Sen, db.Jensiyat, db.Address, db.Mobile, db.Tel, db.Email, db.Aks, db.Tozihat);
        }
        protected DataView KarbarShow2()
        {
            string str = "SELECT * FROM TblKarbar";
            return Show3(str);
        }
        protected Boolean KarbarSearch2(int IDKarbar)
        {
            string str = string.Format("SELECT * FROM TblKarbar Where IDKarbar = '{0}'", IDKarbar);
            return find_row(str);
        }
        protected DataTable KarbarComboShow2()
        {
            string str = "SELECT * FROM TblKarbar";
            return find_row1_2(str);
        }
        protected void KarbarDelete2(int IDKarbar)
        {
            obj.KarbarDelete(IDKarbar);
        }
        protected void KarbarUpdate2(KarbarDB db)
        {
            obj.KarbarUpdate(db.IDKarbar, db.UserName, db.Password, db.NameKarbar, db.FamilyKarbar, db.Semat, db.Madrak, db.CodeMeli, db.TarikheTavalod, db.Sen, db.Jensiyat, db.Address, db.Mobile, db.Tel, db.Email, db.Aks, db.Tozihat);

        }
        protected DataRow KarbarFind2(int IDKarbar)
        {
            string strsql = string.Format("SELECT * FROM TblKarbar Where IDKarbar = '{0}'", IDKarbar);
            return find_row1(strsql);
        }
        protected DataTable KarbarSearchID2()
        {
            string str = "SELECT * FROM TblKarbar";
            return find_row1_2(str);
        }
    }
}
