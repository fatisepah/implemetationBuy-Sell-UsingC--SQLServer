﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL1
{
    public class FactorDB
    {
        public int IDFactor { set; get; }
        public int FKMoshtari { set; get; }
        public string NameMoshtari { set; get; }
        public string NameKarbar { set; get; }
        public string TarikheFactor { set; get; }
        public string DarsadeTakhfif { set; get; }
        public string NameRanande { set; get; }
        public long DastMozdeKargareBarbari { set; get; }
        public long KerayeHaml { set; get; }

    }
}
