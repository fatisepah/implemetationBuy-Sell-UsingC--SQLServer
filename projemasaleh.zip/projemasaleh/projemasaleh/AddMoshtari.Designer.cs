﻿namespace projemasaleh
{
    partial class AddMoshtari
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.idmoshtaritxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.namemoshtaritxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.mobilemtxt = new System.Windows.Forms.MaskedTextBox();
            this.emailmoshtaritxt = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.addresskartxt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.addresskhanetxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblkarbar = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(241, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 23);
            this.label4.TabIndex = 46;
            this.label4.Text = "*";
            // 
            // idmoshtaritxt
            // 
            this.idmoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idmoshtaritxt.Location = new System.Drawing.Point(257, 31);
            this.idmoshtaritxt.Name = "idmoshtaritxt";
            this.idmoshtaritxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idmoshtaritxt.Size = new System.Drawing.Size(116, 20);
            this.idmoshtaritxt.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(22, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 45;
            this.label5.Text = "*";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(404, 15);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(67, 23);
            this.label25.TabIndex = 34;
            this.label25.Text = ":نام کاربر";
            // 
            // namemoshtaritxt
            // 
            this.namemoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namemoshtaritxt.Location = new System.Drawing.Point(39, 31);
            this.namemoshtaritxt.Name = "namemoshtaritxt";
            this.namemoshtaritxt.Size = new System.Drawing.Size(116, 20);
            this.namemoshtaritxt.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(162, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 23);
            this.label3.TabIndex = 43;
            this.label3.Text = "نام مشتری:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(380, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 23);
            this.label2.TabIndex = 42;
            this.label2.Text = "کد مشتری:";
            // 
            // mobilemtxt
            // 
            this.mobilemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mobilemtxt.Location = new System.Drawing.Point(257, 64);
            this.mobilemtxt.Mask = "99999999999";
            this.mobilemtxt.Name = "mobilemtxt";
            this.mobilemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mobilemtxt.Size = new System.Drawing.Size(116, 20);
            this.mobilemtxt.TabIndex = 6;
            // 
            // emailmoshtaritxt
            // 
            this.emailmoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emailmoshtaritxt.Location = new System.Drawing.Point(38, 167);
            this.emailmoshtaritxt.Name = "emailmoshtaritxt";
            this.emailmoshtaritxt.Size = new System.Drawing.Size(336, 20);
            this.emailmoshtaritxt.TabIndex = 9;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.idmoshtaritxt);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.namemoshtaritxt);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.mobilemtxt);
            this.groupBox2.Controls.Add(this.emailmoshtaritxt);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.addresskartxt);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.addresskhanetxt);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(17, 42);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(468, 204);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "اطلاعات مشتریان حقیقی / فروشندگان";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(380, 167);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 23);
            this.label21.TabIndex = 33;
            this.label21.Text = "ایمیل:";
            // 
            // addresskartxt
            // 
            this.addresskartxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addresskartxt.Location = new System.Drawing.Point(38, 132);
            this.addresskartxt.Name = "addresskartxt";
            this.addresskartxt.Size = new System.Drawing.Size(336, 20);
            this.addresskartxt.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(377, 134);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 23);
            this.label12.TabIndex = 7;
            this.label12.Text = "آدرس محل کار:";
            // 
            // addresskhanetxt
            // 
            this.addresskhanetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addresskhanetxt.Location = new System.Drawing.Point(38, 98);
            this.addresskhanetxt.Name = "addresskhanetxt";
            this.addresskhanetxt.Size = new System.Drawing.Size(336, 20);
            this.addresskhanetxt.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(365, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 23);
            this.label7.TabIndex = 2;
            this.label7.Text = "آدرس منزل:";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(379, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 23);
            this.label8.TabIndex = 1;
            this.label8.Text = "موبایل:";
            // 
            // lblkarbar
            // 
            this.lblkarbar.Location = new System.Drawing.Point(281, 15);
            this.lblkarbar.Name = "lblkarbar";
            this.lblkarbar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblkarbar.Size = new System.Drawing.Size(124, 23);
            this.lblkarbar.TabIndex = 33;
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::projemasaleh.Properties.Resources.cross_script3;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(163, 259);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 36;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::projemasaleh.Properties.Resources.save_16x164;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(259, 259);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 35;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // AddMoshtari
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(503, 302);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lblkarbar);
            this.Controls.Add(this.sabtbtn);
            this.Name = "AddMoshtari";
            this.Text = "مشتری";
            this.Load += new System.EventHandler(this.AddMoshtari_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox idmoshtaritxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox namemoshtaritxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox mobilemtxt;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.TextBox emailmoshtaritxt;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox addresskartxt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox addresskhanetxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblkarbar;
        private System.Windows.Forms.Button sabtbtn;
    }
}