﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL1;
using BLL;

namespace projemasaleh
{
    public partial class Factor : Form
    {
        public Factor()
        {
            InitializeComponent();
        }
        FactorData FData = new FactorData();
        RizFactorData RFData = new RizFactorData();

        private void darjbtn_Click(object sender, EventArgs e)
        {
            AddFactor obj = new AddFactor();
            obj.Show();
        }

        private void virayeshbtn_Click(object sender, EventArgs e)
        {
            AddFactor obj = new AddFactor();
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show(".دیتا گرید ویو خالی است", "", MessageBoxButtons.OK);
            }
            else
            {
                int k = dataGridView1.CurrentCell.RowIndex;
                Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                if (obj.ShowDialog() == DialogResult.OK) { }

                dataGridView1.DataSource = true;
                dataGridView1.DataSource = FData.FactorShow1();
                dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Factor_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = FData.FactorShow1 ();
            dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];

        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            int IDFactor = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            int FKMoshtari = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value);
            int IDFactorKHF = Convert.ToInt32(dataGridView1.CurrentRow.Cells[2].Value);
            RFData.RizFactorKharidForoshDelete1(IDFactorKHF, IDFactor);
            FData.FactorDelete1(IDFactor, FKMoshtari);
            if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
            {
                dataGridView1.DataSource =FData.FactorShow1 ();
                this.dataGridView1.Refresh();
            }
            dataGridView1.DataSource = FData.FactorShow1 ();
            this.dataGridView1.Refresh();
        }
    }
}
