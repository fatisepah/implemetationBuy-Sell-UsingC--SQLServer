﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL1
{
    public class FactorManagement : SqlClass
    {
        linqDataContext obj = new linqDataContext();
        protected void FactorInsert2(FactorDB db)
        {
            obj.FactorInsert(db.IDFactor, db.FKMoshtari, db.NameMoshtari, db.NameKarbar, db.TarikheFactor, db.DarsadeTakhfif, db.NameRanande, db.DastMozdeKargareBarbari, db.KerayeHaml);
        }
        protected Boolean FactorSearch2(int IDFactor)
        {
            string str = string.Format("SELECT * FROM TblFactor Where IDFactor= '{0}'", IDFactor);
            return find_row(str);
        }
        protected DataView FactorShow2()
        {
            string str = "SELECT * FROM ViewFactor";
            return Show3(str);
        }
        protected DataTable FactorComboShow2()
        {
            string str = "SELECT * FROM ViewFactor";
            return find_row1_2(str);
        }
        protected void FactorDelete2(int IDFactor, int FKMoshtari)
        {
            obj.FactorDelete(IDFactor, FKMoshtari);
        }
        protected void FactorUpdate2(FactorDB db)
        {
            obj.FactorUpdate(db.IDFactor, db.FKMoshtari, db.NameMoshtari, db.NameKarbar, db.TarikheFactor, db.DarsadeTakhfif, db.NameRanande, db.DastMozdeKargareBarbari, db.KerayeHaml);

        }
    }
}