﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL1;
using BLL;
using System.IO;
namespace projemasaleh
{
    public partial class AddKarbar : Form
    {
        public AddKarbar()
        {
            InitializeComponent();
        }
        string AksName = "";
        KarbarData objK = new KarbarData();
        KarbarDB DBK = new KarbarDB();
        private byte[] ReadFile(string spath)
        {
            byte[] data = null;
            if (spath != "")
            {
                FileInfo finfo = new FileInfo(spath);
                long numbytes = finfo.Length;
                FileStream fstream = new FileStream(spath, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fstream);
                data = br.ReadBytes((int)numbytes);
            }
            return data;
        }
        private void searchbtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            DialogResult dlgRes = dlg.ShowDialog();
            if (dlgRes != DialogResult.Cancel)
            {
                pic.ImageLocation = dlg.FileName;
                AksName = dlg.FileName;
            }
            if (delbtn.Visible == false)
                delbtn.Visible = true;
        }

        private void delbtn_Click(object sender, EventArgs e)
        {
            pic.Image = null;
            delbtn.Visible = false;
            AksName = AksName = @"C:\Users\nanoo\Desktop\projemasaleh\projemasaleh\Resources\error11.png";
            pic.Image = global::projemasaleh.Properties.Resources.error11;
        }

        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (usertxt.Text != "" && passtxt.Text != "" && nametxt.Text != "" && familytxt.Text != "" && sematcmb.Text != "" && madrakcmb.Text != "" && codemelimtxt.Text != "" && tarikhetavalodmtxt.Text != "    /  /" && jenseiatcmb.Text != "" && addresstxt.Text != "" && mobilemtxt.Text != "" && telmtxt.Text != "")
            {
                DBK.IDKarbar = Convert.ToInt32(idkarbartxt.Text);
                DBK.UserName = usertxt.Text;
                DBK.Password = passtxt.Text;
                DBK.NameKarbar = nametxt.Text;
                DBK.FamilyKarbar = familytxt.Text;
                DBK.Semat = sematcmb.Text;
                DBK.Madrak = madrakcmb.Text;
                DBK.CodeMeli = codemelimtxt.Text;
                DBK.TarikheTavalod = tarikhetavalodmtxt.Text;
                DBK.Sen = Convert.ToInt32(senmtxt.Text);
                DBK.Jensiyat = jenseiatcmb.Text;
                DBK.Address = addresstxt.Text;
                DBK.Mobile = mobilemtxt.Text;
                DBK.Tel = telmtxt.Text;
                DBK.Email = emailtxt.Text;
                if (AksName == "")
                    DBK.Aks = ReadFile(@"C:\Users\nanoo\Desktop\projemasaleh\projemasaleh\Resources\error11.png");
                else
                    DBK.Aks = ReadFile(AksName);
                DBK.Tozihat = tozihattxt.Text;
                if (Class1.virayesh != 0)
                {


                    objK.KarbarUpdate1(DBK);
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    Class1.virayesh = 0;
                    Class1.IDKarbar = Convert.ToInt32(idkarbartxt.Text);
                    idkarbartxt.Text = "";
                    usertxt.Text = "";
                    passtxt.Text = "";
                    nametxt.Text = "";
                    familytxt.Text = "";
                    sematcmb.Text = "";
                    madrakcmb.Text = "";
                    codemelimtxt.Text = "";
                    tarikhetavalodmtxt.Text = "";
                    senmtxt.Text = "";
                    jenseiatcmb.Text = "";
                    addresstxt.Text = "";
                    mobilemtxt.Text = "";
                    telmtxt.Text = "";
                    emailtxt.Text = "";
                    tozihattxt.Text = "";
                    Close();

                }
                else
                {
                    if (!objK.KarbarSearch1(DBK.IDKarbar ))
                    {
                        ///تعریف کاربر جدید
                        objK.KarbarInsert1(DBK);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDKarbar = Convert.ToInt32(idkarbartxt.Text);
                            idkarbartxt.Text = "";
                            usertxt.Text = "";
                            passtxt.Text = "";
                            nametxt.Text = "";
                            familytxt.Text = "";
                            sematcmb.Text = "";
                            madrakcmb.Text = "";
                            codemelimtxt.Text = "";
                            tarikhetavalodmtxt.Text = "";
                            senmtxt.Text = "";
                            jenseiatcmb.Text = "";
                            addresstxt.Text = "";
                            mobilemtxt.Text = "";
                            telmtxt.Text = "";
                            emailtxt.Text = "";
                            tozihattxt.Text = "";
                            Close();
                        }

                    }
                    else
                    {
                        MessageBox.Show("کد کالای خرید و فروش تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //
            //
            //
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AddKarbar_Load(object sender, EventArgs e)
        {
            int i1 = 0;
            int i2 = 1;
            if (Class1.virayesh != 0)
            {
                DBK = objK.KarbarFind1(Class1.virayesh);
                idkarbartxt .Text = DBK.IDKarbar.ToString();
                usertxt .Text = DBK.NameKarbar;
                passtxt .Text = DBK.Password;
                nametxt .Text = DBK.NameKarbar;
                familytxt .Text = DBK.FamilyKarbar.ToString();
                sematcmb .Text = DBK.Semat .ToString();
                madrakcmb .Text = DBK.Madrak .ToString();
                codemelimtxt .Text = DBK.CodeMeli.ToString();
                tarikhetavalodmtxt .Text = DBK.TarikheTavalod .ToString();
                senmtxt  .Text = DBK.Sen.ToString();
                jenseiatcmb.Text = DBK.Jensiyat.ToString();
                addresstxt .Text = DBK.Address.ToString();
                mobilemtxt .Text = DBK.Mobile.ToString();
                telmtxt .Text = DBK.Tel .ToString();
                emailtxt.Text = DBK.Email .ToString();
                //AksName.Text = DBK.Aks.ToString();
                tozihattxt .Text = DBK.Tozihat .ToString();
            }
            else
            {
                DataTable dt = objK.KarbarSearchID1 ();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idkarbartxt .Text = "1";
                }
                else
                {
                    idkarbartxt.Text = Convert.ToString(i2 + 1);
                }

            }
        }
    }
}
