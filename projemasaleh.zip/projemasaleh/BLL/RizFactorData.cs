﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL1;
using System.Data;

namespace BLL
{
    public class RizFactorData : RizFactorManagement
    {
        public void RizFactorKharidForoshInsert1(RizFactorDB bd)
        {
            RizFactorKharidForoshInsert2(bd);
        }
        public Boolean RizFactorKharidForoshSearch1(int IDFactorKHF)
        {
            return RizFactorKharidForoshSearch2(IDFactorKHF);
        }
        public void RizFactorKharidForoshDelete1(int IDFactorKHF, int FKFactor)
        {
            RizFactorKharidForoshDelete2(IDFactorKHF, FKFactor);
        }
        public void RizFactorKharidForoshUpdate1(RizFactorDB bd)
        {
            RizFactorKharidForoshUpdate2(bd);
        }
    }
}
