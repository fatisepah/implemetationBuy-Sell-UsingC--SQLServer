﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace projemasaleh
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void کابرانToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Karbar obj = new Karbar();
            obj.Show();
        }

        private void مشتریToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Moshtari  obj = new Moshtari ();
            obj.Show();
        }

        private void لوازمساختمانیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Kalaha obj = new Kalaha();
            obj.Show();
        }

        private void فاکتورخریدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Factor obj = new Factor();
            obj.Show();
        }

        private void فاکتورفروشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Factor obj = new Factor();
            obj.Show();
        }
    }
}
