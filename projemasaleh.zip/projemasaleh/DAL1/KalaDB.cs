﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL1
{
    public class KalaDB
    {
        public int IDKala { set; get; }
        public string NameKala { set; get; }
        public string VahedeShomaresheAsli { set; get; }
        public string VahedeShomaresheFare { set; get; }
        public int HadeaghaleTedadeMojod { set; get; }
        public int TedadeKala { set; get; }
        public string Tozihat { set; get; }
        public string TarikheTolid { set; get; }
        public string TarikheEngheza { set; get; }
        public long GheimateKharid { set; get; }
        public long GheimateForosh { set; get; }
        public string Garanty { set; get; }
        public string ModeleKala { set; get; }
        public string BarcodeKala { set; get; }
        public string NameSherkatTolidi { set; get; }
    }
}
