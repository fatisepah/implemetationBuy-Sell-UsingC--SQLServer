﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace projemasaleh
{
   public  class Class1
    {
       public static int virayesh = 0;
       public static int IDKala = 0;
       public static int IDKarbar = 0;
       public static int IDMoshtari = 0;

    }
}
