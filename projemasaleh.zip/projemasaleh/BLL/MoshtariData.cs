﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL1;
using System.Data;
using System.Data.SqlClient;
namespace BLL
{
    public class MoshtariData : MoshtariManagement
    {
        public void MoshtariInsert1(MoshtariDB bd)
        {
            MoshtariInsert2(bd);
        }
        public Boolean MoshtariSearch1(int IDMoshtari)
        {
            return MoshtariSearch2(IDMoshtari);
        }
        public DataTable MoshtariComboShow1()
        {
            return MoshtariComboShow2();
        }
        public DataView MoshtariShow1()
        {
            return MoshtariShow2();
        }
        public void MoshtariDelete1(int IDMoshtari)
        {
            MoshtariDelete2(IDMoshtari);
        }
        public void MoshtariUpdate1(MoshtariDB bd)
        {
            MoshtariUpdate2(bd);
        }
        public MoshtariDB MoshtariFind1(int IDMoshtari)
        {
            DataRow dr = MoshtariFind2(IDMoshtari);
            MoshtariDB bd = new MoshtariDB();
            bd.IDMoshtari = Convert.ToInt32(dr[0].ToString());
            bd.NameMoshtari = dr[1].ToString();
            bd.Mobile = dr[2].ToString();
            bd.AddressKhane  = dr[3].ToString();
            bd.AddressKar  = dr[4].ToString();
            bd.Email  =dr[5].ToString();

            return bd;
        }
        public DataTable MoshtariSearchID1()
        {
            return MoshtariSearchID2();
        }
    }
}