﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL1
{
    public class RizFactorDB
    {
        public int IDFactorKHF { set; get; }
        public string NameKalayeKharidForosh1 { set; get; }
        public int Tedade1 { set; get; }
        public string NameKalayeKharidForosh2 { set; get; }
        public int Tedade2 { set; get; }
        public string NameKalayeKharidForosh3 { set; get; }
        public int Tedade3 { set; get; }
        public string NameKalayeKharidForosh4 { set; get; }
        public int Tedade4 { set; get; }
        public string NameKalayeKharidForosh5 { set; get; }
        public int Tedade5 { set; get; }
        public int FKFactor { set; get; }
        public long GheimateKol { set; get; }
    }
}
