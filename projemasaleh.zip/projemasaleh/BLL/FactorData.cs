﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL1;
using System.Data;
namespace BLL
{
    public class FactorData : FactorManagement
    {
        public void FactorInsert1(FactorDB bd)
        {
            FactorInsert2(bd);
        }
        public Boolean FactorSearch1(int IDFactor)
        {
            return FactorSearch2(IDFactor);
        }
        public DataView FactorShow1()
        {
            return FactorShow2();
        }
        public DataTable FactorComboShow1()
        {
            return FactorComboShow2();
        }
        public void FactorDelete1(int IDFactor, int FKMoshtari)
        {
            FactorDelete2(IDFactor, FKMoshtari);
        }
        public void FactorUpdate1(FactorDB bd)
        {
            FactorUpdate2(bd);
        }
    }
}
