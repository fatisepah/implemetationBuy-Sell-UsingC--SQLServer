﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL1
{
    public class MoshtariManagement : SqlClass
    {
        linqDataContext obj = new linqDataContext();
        protected void MoshtariInsert2(MoshtariDB db)
        {
            obj.MoshtariInsert(db.IDMoshtari, db.NameMoshtari, db.Mobile, db.AddressKhane, db.AddressKar, db.Email);
        }

        protected Boolean MoshtariSearch2(int IDMoshtari)
        {
            string str = string.Format("select * from TblMoshtari Where IDMoshtari = '{0}'", IDMoshtari);
            return find_row(str);
        }
        protected DataTable MoshtariComboShow2()
        {
            string str = "Select * from  TblMoshtari";
            return find_row1_2(str);
        }
        protected DataView MoshtariShow2()
        {
            string str = "SELECT * FROM TblMoshtari";
            return Show3(str);
        }
        protected void MoshtariDelete2(int IDMoshtari)
        {
            obj.MoshtariDelete(IDMoshtari);
        }
        protected void MoshtariUpdate2(MoshtariDB db)
        {
            obj.MoshtariUpdate(db.IDMoshtari, db.NameMoshtari, db.Mobile, db.AddressKhane, db.AddressKar, db.Email);
        }
        protected DataRow MoshtariFind2(int IDMoshtari)
        {
            string strsql = string.Format("SELECT * FROM TblMoshtari Where IDMoshtari = '{0}'", IDMoshtari);
            return find_row1(strsql);
        }
        protected DataTable MoshtariSearchID2()
        {
            string str = "SELECT * FROM TblMoshtari";
            return find_row1_2(str);
        }
    }
}
