﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL1;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public class KalaData : KalaManagement
    {
        public DataView KalayeKharidForoshShow1()
        {
            return KalayeKharidForoshShow2();
        }
        public void KalaInsert1(KalaDB bd)
        {
            KalaInsert2(bd);
        }
        public Boolean KalayeKharidForoshSearch1(int IDKala)
        {
            return KalayeKharidForoshSearch2(IDKala);
        }
        public DataTable KalayeKharidForoshComboShow1()
        {
            return KalayeKharidForoshComboShow2();
        }
        public void KalayeKharidForoshDelete1(int IDKalaKHF)
        {
            KalayeKharidForoshDelete2(IDKalaKHF);
        }
        public void KalayeKharidForoshUpdate1(KalaDB bd)
        {
            KalayeKharidForoshUpdate2(bd);
        }
        public KalaDB  KalayeKharidForoshFind1(int IDKala)
        {
            DataRow dr = KalayeKharidForoshFind2(IDKala);
            KalaDB bd = new KalaDB();
            bd.IDKala = Convert.ToInt32(dr[0].ToString());
            bd.NameKala = dr[1].ToString();
            bd.VahedeShomaresheAsli  =dr[2].ToString();
            bd.VahedeShomaresheFare = dr[3].ToString();
            bd.HadeaghaleTedadeMojod = Convert.ToInt32(dr[4].ToString());
            bd.TedadeKala =Convert.ToInt32( dr[5].ToString());
            bd.Tozihat  = dr[6].ToString();
            bd.TarikheTolid = dr[7].ToString();
            bd.TarikheEngheza = dr[8].ToString();
            bd.GheimateKharid = Convert.ToInt64(dr[9].ToString());
            bd.GheimateForosh = Convert.ToInt64(dr[10].ToString());
            bd.Garanty = dr[11].ToString();
            bd.ModeleKala = dr[12].ToString();
            bd.BarcodeKala = dr[13].ToString();
            bd.NameSherkatTolidi = dr[14].ToString();

            return bd;
        }
        public DataTable KalayeKharidForoshSearchID1()
        {
            return KalayeKharidForoshSearchID2();
        }
    }
}
