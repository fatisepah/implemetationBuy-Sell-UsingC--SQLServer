﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using DAL1;
namespace BLL
{
    public class KarbarData : KarbarManagement
    {
        DataView dw = new DataView();
        private byte[] ReadFile(string spath)
        {
            byte[] data = null;
            if (spath != "")
            {
                FileInfo finfo = new FileInfo(spath);
                long numbytes = finfo.Length;
                FileStream fstream = new FileStream(spath, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fstream);
                data = br.ReadBytes((int)numbytes);
            }
            return data;
        }
        public void KarbarInsert1(KarbarDB bd)
        {
            KarbarInsert2(bd);
        }
        public DataView KarbarShow1()
        {
            return KarbarShow2();
        }
        public Boolean KarbarSearch1(int IDKarbar)
        {
            return KarbarSearch2(IDKarbar);
        }
        public DataTable KarbarComboShow1()
        {
            return KarbarComboShow2();
        }
        public void KarbarDelete1(int IDKarbar)
        {
            KarbarDelete2(IDKarbar);
        }
        public void KarbarUpdate1(KarbarDB bd)
        {
            KarbarUpdate2(bd);
        }
        public KarbarDB KarbarFind1(int IDKarbar)
        {
            DataRow dr = KarbarFind2(IDKarbar);
            KarbarDB bd = new KarbarDB();
            bd.IDKarbar = Convert.ToInt32(dr[0].ToString());
            bd.UserName = dr[1].ToString();
            bd.Password = dr[2].ToString();
            bd.NameKarbar = dr[3].ToString();
            bd.FamilyKarbar = dr[4].ToString();
            bd.Semat  = dr[5].ToString();
            bd.Madrak = dr[6].ToString();
            bd.CodeMeli = dr[7].ToString();
            bd.TarikheTavalod = dr[8].ToString();
            bd.Sen  =Convert.ToInt32( dr[9].ToString());
            bd.Jensiyat = dr[10].ToString();
            bd.Address = dr[11].ToString();
            bd.Mobile = dr[12].ToString();
            bd.Tel  = dr[13].ToString();
            bd.Email = dr[14].ToString();
            string s = dr[15].ToString();
            if (dr[15].ToString() != "")
                bd.Aks = (byte[])dr[15];
            bd.Tozihat  = dr[16].ToString();

            return bd;
        }
        public DataTable KarbarSearchID1()
        {
            return KarbarSearchID2();
        }
    }
}
