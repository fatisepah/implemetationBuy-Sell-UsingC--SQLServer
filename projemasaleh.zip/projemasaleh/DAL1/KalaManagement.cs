﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL1
{
    public class KalaManagement : SqlClass
    {
        linqDataContext obj = new linqDataContext();
        protected DataView KalayeKharidForoshShow2()
        {
            string str = "SELECT * FROM TblKala";
            return Show3(str);
        }
        protected void KalaInsert2(KalaDB db)
        {
            obj.KalayeKharidForoshInsert(db.IDKala, db.NameKala, db.VahedeShomaresheAsli, db.VahedeShomaresheFare, db.HadeaghaleTedadeMojod, db.TedadeKala, db.Tozihat, db.TarikheTolid, db.TarikheEngheza, db.GheimateKharid, db.GheimateForosh, db.Garanty, db.ModeleKala, db.BarcodeKala, db.NameSherkatTolidi);
        }
        protected Boolean KalayeKharidForoshSearch2(int IDKala)
        {
            string str = string.Format("SELECT * FROM TblKala Where IDKala = '{0}'", IDKala);
            return find_row(str);
        }
        protected DataTable KalayeKharidForoshComboShow2()
        {
            string str = "SELECT * FROM TblKala";
            return find_row1_2(str);
        }
        protected void KalayeKharidForoshDelete2(int IDKalaKHF)
        {
            obj.KalayeKharidForoshDelete(IDKalaKHF);
        }
        protected void KalayeKharidForoshUpdate2(KalaDB db)
        {
            obj.KalayeKharidForoshUpdate(db.IDKala, db.NameKala, db.VahedeShomaresheAsli, db.VahedeShomaresheFare, db.HadeaghaleTedadeMojod, db.TedadeKala, db.Tozihat, db.TarikheTolid, db.TarikheEngheza, db.GheimateKharid, db.GheimateForosh, db.Garanty, db.ModeleKala, db.BarcodeKala, db.NameSherkatTolidi);

        }
        protected DataRow KalayeKharidForoshFind2(int IDKala)
        {
            string strsql = string.Format("SELECT * FROM TblKala Where IDKala = '{0}'", IDKala);
            return find_row1(strsql);
        }
        protected DataTable KalayeKharidForoshSearchID2()
        {
            string str = "SELECT * FROM TblKala";
            return find_row1_2(str);
        }
    }
}