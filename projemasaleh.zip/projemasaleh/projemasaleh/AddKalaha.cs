﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL1;
using BLL;
namespace projemasaleh
{
    public partial class AddKalaha : Form
    {
        public AddKalaha()
        {
            InitializeComponent();
        }
        KalaData KKFData = new KalaData();
        KalaDB KKFDB = new KalaDB();
        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idkalakhfmtxt.Text != "" && namekalatxt.Text != "" && hadeaghaletedadmojodmtxt.Text != "" && tedadekalamtxt.Text != "" && gheimatekharidmtxt.Text != "" && gheimatforoshmtxt.Text != "")
            {
                KKFDB.IDKala = Convert.ToInt32(idkalakhfmtxt.Text);
                KKFDB.NameKala = namekalatxt.Text;
                KKFDB.VahedeShomaresheAsli = vahedaslitxt.Text;
                KKFDB.VahedeShomaresheFare = vahedfareetxt.Text;
                KKFDB.HadeaghaleTedadeMojod = Convert.ToInt32(hadeaghaletedadmojodmtxt.Text);
                KKFDB.TedadeKala = Convert.ToInt32(tedadekalamtxt.Text);
                KKFDB.Tozihat = tozihattxt.Text;
                KKFDB.TarikheTolid = tarikhtolidmtxt.Text;
                KKFDB.TarikheEngheza = tarikhenghezamtxt.Text;
                KKFDB.GheimateKharid = Convert.ToInt64(gheimatekharidmtxt.Text.Replace(",", ""));
                KKFDB.GheimateForosh = Convert.ToInt64(gheimatforoshmtxt.Text.Replace(",", ""));
                KKFDB.Garanty = garantytxt.Text;
                KKFDB.ModeleKala = modeltxt.Text;
                KKFDB.BarcodeKala = barcodemtxt.Text;
                KKFDB.NameSherkatTolidi = namesherkattxt.Text;
                 if (Class1.virayesh != 0)
                {

                        KKFData.KalayeKharidForoshUpdate1  (KKFDB);
                        MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        Class1.virayesh = 0;
                        Class1.IDKala  = Convert.ToInt32(idkalakhfmtxt.Text);
                        idkalakhfmtxt .Text = "";
                        namekalatxt.Text = "";
                        vahedaslitxt .Text = "";
                        vahedfareetxt .Text = "";
                        hadeaghaletedadmojodmtxt .Text = "";
                        tedadekalamtxt .Text = "";
                        tozihattxt .Text = "";
                        tarikhtolidmtxt .Text = "";
                        tarikhenghezamtxt .Text = "";
                        gheimatekharidmtxt .Text = "";
                        gheimatforoshmtxt .Text = "";
                        garantytxt.Text = "";
                        modeltxt .Text = "";
                        barcodemtxt .Text = "";
                        namesherkattxt .Text = "";
                        Close();
                    
                }
                else
                {
                if (!KKFData.KalayeKharidForoshSearch1(KKFDB.IDKala))
                {
                    KKFData.KalaInsert1 (KKFDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDKala = Convert.ToInt32(idkalakhfmtxt.Text);
                         idkalakhfmtxt .Text = "";
                        namekalatxt.Text = "";
                        vahedaslitxt .Text = "";
                        vahedfareetxt .Text = "";
                        hadeaghaletedadmojodmtxt .Text = "";
                        tedadekalamtxt .Text = "";
                        tozihattxt .Text = "";
                        tarikhtolidmtxt .Text = "";
                        tarikhenghezamtxt .Text = "";
                        gheimatekharidmtxt .Text = "";
                        gheimatforoshmtxt .Text = "";
                        garantytxt.Text = "";
                        modeltxt .Text = "";
                        barcodemtxt .Text = "";
                        namesherkattxt .Text = "";
                        }
                        this.Close();
                    }
                else
                {
                    MessageBox.Show("کد کالای خرید و فروش تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                }

            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AddKalaha_Load(object sender, EventArgs e)
        {
            int i1 = 0;
            int i2 = 1;
            if (Class1.virayesh != 0)
            {
                KKFDB = KKFData.KalayeKharidForoshFind1 (Class1.virayesh);
                idkalakhfmtxt.Text = KKFDB.IDKala .ToString();
                namekalatxt.Text = KKFDB.NameKala;
                vahedaslitxt .Text = KKFDB.VahedeShomaresheAsli ;
                vahedfareetxt .Text = KKFDB.VahedeShomaresheFare ;
                hadeaghaletedadmojodmtxt.Text = KKFDB.HadeaghaleTedadeMojod.ToString();
                tozihattxt .Text = KKFDB.Tozihat .ToString();
                tarikhtolidmtxt .Text = KKFDB.TarikheTolid .ToString();
                tarikhenghezamtxt .Text = KKFDB.TarikheEngheza .ToString();
                gheimatekharidmtxt .Text = KKFDB.GheimateKharid .ToString();
                gheimatforoshmtxt .Text = KKFDB.GheimateForosh .ToString();
                garantytxt.Text = KKFDB.Garanty .ToString();
                modeltxt .Text = KKFDB.ModeleKala .ToString();
                barcodemtxt .Text = KKFDB.BarcodeKala.ToString();
                namesherkattxt .Text = KKFDB.NameKala .ToString();
            }
            else
            {
                DataTable dt = KKFData.KalayeKharidForoshSearchID1();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idkalakhfmtxt .Text = "1";
                }
                else
                {
                    idkalakhfmtxt.Text = Convert.ToString(i2 + 1);
                }

            }
        }
    }
}
