﻿namespace projemasaleh
{
    partial class AddFactor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kerayehamltxt = new System.Windows.Forms.TextBox();
            this.id5txt = new System.Windows.Forms.TextBox();
            this.id4txt = new System.Windows.Forms.TextBox();
            this.id3txt = new System.Windows.Forms.TextBox();
            this.id2txt = new System.Windows.Forms.TextBox();
            this.id1txt = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.barcode5txt = new System.Windows.Forms.TextBox();
            this.barcode4txt = new System.Windows.Forms.TextBox();
            this.barcode3txt = new System.Windows.Forms.TextBox();
            this.barcode2txt = new System.Windows.Forms.TextBox();
            this.barcode1txt = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.vahedkala5txt = new System.Windows.Forms.TextBox();
            this.vahedkala4txt = new System.Windows.Forms.TextBox();
            this.vahedkala3txt = new System.Windows.Forms.TextBox();
            this.vahedkala2txt = new System.Windows.Forms.TextBox();
            this.vahedkala1txt = new System.Windows.Forms.TextBox();
            this.gheimateaghlam = new System.Windows.Forms.TextBox();
            this.gheimateradif5txt = new System.Windows.Forms.TextBox();
            this.gheimateradif4txt = new System.Windows.Forms.TextBox();
            this.gheimateradif3txt = new System.Windows.Forms.TextBox();
            this.gheimateradif2txt = new System.Windows.Forms.TextBox();
            this.gheimateradif1txt = new System.Windows.Forms.TextBox();
            this.dastmozdekargartxt = new System.Windows.Forms.TextBox();
            this.takhfiftxt = new System.Windows.Forms.TextBox();
            this.gheimatekoltxt = new System.Windows.Forms.TextBox();
            this.nameranandetxt = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.namemoshtaricmb = new System.Windows.Forms.ComboBox();
            this.idmoshtaritxt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tarikhmtxt = new System.Windows.Forms.MaskedTextBox();
            this.lblkarbar = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.idfactortxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.darsadkarmozdtxt = new System.Windows.Forms.TextBox();
            this.darsadmaliyattxt = new System.Windows.Forms.TextBox();
            this.darsadetakhfiftxt = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.karmozdtxt = new System.Windows.Forms.TextBox();
            this.maliayattxt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.gheimatkala5txt = new System.Windows.Forms.TextBox();
            this.gheimatkala4txt = new System.Windows.Forms.TextBox();
            this.gheimatkala3txt = new System.Windows.Forms.TextBox();
            this.gheimatkala2txt = new System.Windows.Forms.TextBox();
            this.gheimatkala1txt = new System.Windows.Forms.TextBox();
            this.tedadkala5nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala4nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala3nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala2nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala1nud = new System.Windows.Forms.NumericUpDown();
            this.namekala5cmb = new System.Windows.Forms.ComboBox();
            this.namekala4cmb = new System.Windows.Forms.ComboBox();
            this.namekala3cmb = new System.Windows.Forms.ComboBox();
            this.namekala2cmb = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.namekala1cmb = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape11 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape10 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape4 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape3 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape2 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala5nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala4nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala3nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala2nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala1nud)).BeginInit();
            this.SuspendLayout();
            // 
            // kerayehamltxt
            // 
            this.kerayehamltxt.Location = new System.Drawing.Point(42, 391);
            this.kerayehamltxt.Multiline = true;
            this.kerayehamltxt.Name = "kerayehamltxt";
            this.kerayehamltxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.kerayehamltxt.Size = new System.Drawing.Size(149, 24);
            this.kerayehamltxt.TabIndex = 748;
            this.kerayehamltxt.Text = "0";
            // 
            // id5txt
            // 
            this.id5txt.Location = new System.Drawing.Point(688, 300);
            this.id5txt.Multiline = true;
            this.id5txt.Name = "id5txt";
            this.id5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id5txt.Size = new System.Drawing.Size(56, 22);
            this.id5txt.TabIndex = 747;
            // 
            // id4txt
            // 
            this.id4txt.Location = new System.Drawing.Point(688, 276);
            this.id4txt.Multiline = true;
            this.id4txt.Name = "id4txt";
            this.id4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id4txt.Size = new System.Drawing.Size(56, 22);
            this.id4txt.TabIndex = 746;
            // 
            // id3txt
            // 
            this.id3txt.Location = new System.Drawing.Point(688, 252);
            this.id3txt.Multiline = true;
            this.id3txt.Name = "id3txt";
            this.id3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id3txt.Size = new System.Drawing.Size(56, 22);
            this.id3txt.TabIndex = 745;
            // 
            // id2txt
            // 
            this.id2txt.Location = new System.Drawing.Point(688, 228);
            this.id2txt.Multiline = true;
            this.id2txt.Name = "id2txt";
            this.id2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id2txt.Size = new System.Drawing.Size(56, 22);
            this.id2txt.TabIndex = 744;
            // 
            // id1txt
            // 
            this.id1txt.Location = new System.Drawing.Point(688, 204);
            this.id1txt.Multiline = true;
            this.id1txt.Name = "id1txt";
            this.id1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id1txt.Size = new System.Drawing.Size(56, 22);
            this.id1txt.TabIndex = 743;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label66.Location = new System.Drawing.Point(699, 177);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(39, 23);
            this.label66.TabIndex = 742;
            this.label66.Text = "کد کالا";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // barcode5txt
            // 
            this.barcode5txt.Location = new System.Drawing.Point(567, 300);
            this.barcode5txt.Multiline = true;
            this.barcode5txt.Name = "barcode5txt";
            this.barcode5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode5txt.Size = new System.Drawing.Size(119, 22);
            this.barcode5txt.TabIndex = 741;
            // 
            // barcode4txt
            // 
            this.barcode4txt.Location = new System.Drawing.Point(567, 276);
            this.barcode4txt.Multiline = true;
            this.barcode4txt.Name = "barcode4txt";
            this.barcode4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode4txt.Size = new System.Drawing.Size(119, 22);
            this.barcode4txt.TabIndex = 740;
            // 
            // barcode3txt
            // 
            this.barcode3txt.Location = new System.Drawing.Point(567, 252);
            this.barcode3txt.Multiline = true;
            this.barcode3txt.Name = "barcode3txt";
            this.barcode3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode3txt.Size = new System.Drawing.Size(119, 22);
            this.barcode3txt.TabIndex = 739;
            // 
            // barcode2txt
            // 
            this.barcode2txt.Location = new System.Drawing.Point(567, 228);
            this.barcode2txt.Multiline = true;
            this.barcode2txt.Name = "barcode2txt";
            this.barcode2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode2txt.Size = new System.Drawing.Size(119, 22);
            this.barcode2txt.TabIndex = 738;
            // 
            // barcode1txt
            // 
            this.barcode1txt.Location = new System.Drawing.Point(567, 204);
            this.barcode1txt.Multiline = true;
            this.barcode1txt.Name = "barcode1txt";
            this.barcode1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode1txt.Size = new System.Drawing.Size(119, 22);
            this.barcode1txt.TabIndex = 737;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label30.Location = new System.Drawing.Point(581, 176);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 23);
            this.label30.TabIndex = 736;
            this.label30.Text = "بارکد کالا";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // vahedkala5txt
            // 
            this.vahedkala5txt.Location = new System.Drawing.Point(328, 300);
            this.vahedkala5txt.Multiline = true;
            this.vahedkala5txt.Name = "vahedkala5txt";
            this.vahedkala5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala5txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala5txt.TabIndex = 735;
            // 
            // vahedkala4txt
            // 
            this.vahedkala4txt.Location = new System.Drawing.Point(328, 276);
            this.vahedkala4txt.Multiline = true;
            this.vahedkala4txt.Name = "vahedkala4txt";
            this.vahedkala4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala4txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala4txt.TabIndex = 734;
            // 
            // vahedkala3txt
            // 
            this.vahedkala3txt.Location = new System.Drawing.Point(328, 252);
            this.vahedkala3txt.Multiline = true;
            this.vahedkala3txt.Name = "vahedkala3txt";
            this.vahedkala3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala3txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala3txt.TabIndex = 733;
            // 
            // vahedkala2txt
            // 
            this.vahedkala2txt.Location = new System.Drawing.Point(328, 228);
            this.vahedkala2txt.Multiline = true;
            this.vahedkala2txt.Name = "vahedkala2txt";
            this.vahedkala2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala2txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala2txt.TabIndex = 732;
            // 
            // vahedkala1txt
            // 
            this.vahedkala1txt.Location = new System.Drawing.Point(328, 204);
            this.vahedkala1txt.Multiline = true;
            this.vahedkala1txt.Name = "vahedkala1txt";
            this.vahedkala1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala1txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala1txt.TabIndex = 731;
            // 
            // gheimateaghlam
            // 
            this.gheimateaghlam.Location = new System.Drawing.Point(42, 326);
            this.gheimateaghlam.Multiline = true;
            this.gheimateaghlam.Name = "gheimateaghlam";
            this.gheimateaghlam.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateaghlam.Size = new System.Drawing.Size(149, 34);
            this.gheimateaghlam.TabIndex = 730;
            this.gheimateaghlam.Text = "0";
            // 
            // gheimateradif5txt
            // 
            this.gheimateradif5txt.Location = new System.Drawing.Point(42, 300);
            this.gheimateradif5txt.Multiline = true;
            this.gheimateradif5txt.Name = "gheimateradif5txt";
            this.gheimateradif5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif5txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif5txt.TabIndex = 729;
            this.gheimateradif5txt.Text = "0";
            // 
            // gheimateradif4txt
            // 
            this.gheimateradif4txt.Location = new System.Drawing.Point(42, 276);
            this.gheimateradif4txt.Multiline = true;
            this.gheimateradif4txt.Name = "gheimateradif4txt";
            this.gheimateradif4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif4txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif4txt.TabIndex = 728;
            this.gheimateradif4txt.Text = "0";
            // 
            // gheimateradif3txt
            // 
            this.gheimateradif3txt.Location = new System.Drawing.Point(42, 252);
            this.gheimateradif3txt.Multiline = true;
            this.gheimateradif3txt.Name = "gheimateradif3txt";
            this.gheimateradif3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif3txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif3txt.TabIndex = 727;
            this.gheimateradif3txt.Text = "0";
            // 
            // gheimateradif2txt
            // 
            this.gheimateradif2txt.Location = new System.Drawing.Point(42, 228);
            this.gheimateradif2txt.Multiline = true;
            this.gheimateradif2txt.Name = "gheimateradif2txt";
            this.gheimateradif2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif2txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif2txt.TabIndex = 726;
            this.gheimateradif2txt.Text = "0";
            // 
            // gheimateradif1txt
            // 
            this.gheimateradif1txt.Location = new System.Drawing.Point(42, 204);
            this.gheimateradif1txt.Multiline = true;
            this.gheimateradif1txt.Name = "gheimateradif1txt";
            this.gheimateradif1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif1txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif1txt.TabIndex = 725;
            this.gheimateradif1txt.Text = "0";
            // 
            // dastmozdekargartxt
            // 
            this.dastmozdekargartxt.Location = new System.Drawing.Point(42, 418);
            this.dastmozdekargartxt.Multiline = true;
            this.dastmozdekargartxt.Name = "dastmozdekargartxt";
            this.dastmozdekargartxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dastmozdekargartxt.Size = new System.Drawing.Size(149, 24);
            this.dastmozdekargartxt.TabIndex = 724;
            this.dastmozdekargartxt.Text = "0";
            // 
            // takhfiftxt
            // 
            this.takhfiftxt.Location = new System.Drawing.Point(42, 363);
            this.takhfiftxt.Multiline = true;
            this.takhfiftxt.Name = "takhfiftxt";
            this.takhfiftxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.takhfiftxt.Size = new System.Drawing.Size(149, 24);
            this.takhfiftxt.TabIndex = 723;
            this.takhfiftxt.Text = "0";
            // 
            // gheimatekoltxt
            // 
            this.gheimatekoltxt.Location = new System.Drawing.Point(42, 501);
            this.gheimatekoltxt.Multiline = true;
            this.gheimatekoltxt.Name = "gheimatekoltxt";
            this.gheimatekoltxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatekoltxt.Size = new System.Drawing.Size(149, 24);
            this.gheimatekoltxt.TabIndex = 722;
            this.gheimatekoltxt.Text = "0";
            // 
            // nameranandetxt
            // 
            this.nameranandetxt.Location = new System.Drawing.Point(599, 365);
            this.nameranandetxt.Name = "nameranandetxt";
            this.nameranandetxt.Size = new System.Drawing.Size(119, 20);
            this.nameranandetxt.TabIndex = 718;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label52.Location = new System.Drawing.Point(724, 367);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(57, 20);
            this.label52.TabIndex = 719;
            this.label52.Text = ":نام راننده";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(464, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 15);
            this.label5.TabIndex = 717;
            this.label5.Text = "*";
            // 
            // namemoshtaricmb
            // 
            this.namemoshtaricmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namemoshtaricmb.FormattingEnabled = true;
            this.namemoshtaricmb.Location = new System.Drawing.Point(414, 150);
            this.namemoshtaricmb.Name = "namemoshtaricmb";
            this.namemoshtaricmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namemoshtaricmb.Size = new System.Drawing.Size(201, 21);
            this.namemoshtaricmb.TabIndex = 665;
            // 
            // idmoshtaritxt
            // 
            this.idmoshtaritxt.Location = new System.Drawing.Point(250, 150);
            this.idmoshtaritxt.Name = "idmoshtaritxt";
            this.idmoshtaritxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idmoshtaritxt.Size = new System.Drawing.Size(163, 20);
            this.idmoshtaritxt.TabIndex = 666;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label12.Location = new System.Drawing.Point(300, 124);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 22);
            this.label12.TabIndex = 683;
            this.label12.Text = ":کد مشتری";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(478, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 22);
            this.label7.TabIndex = 684;
            this.label7.Text = ":نام مشتری";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(288, 126);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 15);
            this.label8.TabIndex = 685;
            this.label8.Text = "*";
            // 
            // tarikhmtxt
            // 
            this.tarikhmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhmtxt.Location = new System.Drawing.Point(106, 80);
            this.tarikhmtxt.Name = "tarikhmtxt";
            this.tarikhmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhmtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhmtxt.TabIndex = 664;
            // 
            // lblkarbar
            // 
            this.lblkarbar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblkarbar.Location = new System.Drawing.Point(106, 54);
            this.lblkarbar.Name = "lblkarbar";
            this.lblkarbar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblkarbar.Size = new System.Drawing.Size(116, 23);
            this.lblkarbar.TabIndex = 689;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(89, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 23);
            this.label2.TabIndex = 681;
            this.label2.Text = "*";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(232, 56);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 23);
            this.label25.TabIndex = 690;
            this.label25.Text = ":نام کاربر";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(231, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 23);
            this.label3.TabIndex = 680;
            this.label3.Text = ":تاریخ";
            // 
            // idfactortxt
            // 
            this.idfactortxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idfactortxt.Location = new System.Drawing.Point(532, 57);
            this.idfactortxt.Name = "idfactortxt";
            this.idfactortxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idfactortxt.Size = new System.Drawing.Size(117, 20);
            this.idfactortxt.TabIndex = 663;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(656, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 23);
            this.label4.TabIndex = 677;
            this.label4.Text = ":کد فاکتور";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(515, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 23);
            this.label1.TabIndex = 682;
            this.label1.Text = "*";
            // 
            // label28
            // 
            this.label28.ForeColor = System.Drawing.Color.Red;
            this.label28.Location = new System.Drawing.Point(282, 451);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 19);
            this.label28.TabIndex = 716;
            this.label28.Text = "(+)";
            // 
            // label27
            // 
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(282, 478);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(29, 19);
            this.label27.TabIndex = 715;
            this.label27.Text = "(+)";
            // 
            // label23
            // 
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(281, 368);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 19);
            this.label23.TabIndex = 714;
            this.label23.Text = " (-)";
            // 
            // darsadkarmozdtxt
            // 
            this.darsadkarmozdtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.darsadkarmozdtxt.Location = new System.Drawing.Point(247, 476);
            this.darsadkarmozdtxt.Multiline = true;
            this.darsadkarmozdtxt.Name = "darsadkarmozdtxt";
            this.darsadkarmozdtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.darsadkarmozdtxt.Size = new System.Drawing.Size(32, 21);
            this.darsadkarmozdtxt.TabIndex = 713;
            this.darsadkarmozdtxt.Text = "0";
            // 
            // darsadmaliyattxt
            // 
            this.darsadmaliyattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.darsadmaliyattxt.Location = new System.Drawing.Point(247, 448);
            this.darsadmaliyattxt.Multiline = true;
            this.darsadmaliyattxt.Name = "darsadmaliyattxt";
            this.darsadmaliyattxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.darsadmaliyattxt.Size = new System.Drawing.Size(32, 21);
            this.darsadmaliyattxt.TabIndex = 712;
            this.darsadmaliyattxt.Text = "0";
            // 
            // darsadetakhfiftxt
            // 
            this.darsadetakhfiftxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.darsadetakhfiftxt.Location = new System.Drawing.Point(248, 365);
            this.darsadetakhfiftxt.Multiline = true;
            this.darsadetakhfiftxt.Name = "darsadetakhfiftxt";
            this.darsadetakhfiftxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.darsadetakhfiftxt.Size = new System.Drawing.Size(32, 21);
            this.darsadetakhfiftxt.TabIndex = 711;
            this.darsadetakhfiftxt.Text = "0";
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(200, 506);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 20);
            this.label22.TabIndex = 710;
            this.label22.Text = ":قیمت کل";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(200, 478);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 23);
            this.label20.TabIndex = 709;
            this.label20.Text = ":کارمزد٪";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(200, 450);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 23);
            this.label19.TabIndex = 708;
            this.label19.Text = ":مالیات٪";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(201, 423);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(90, 23);
            this.label18.TabIndex = 707;
            this.label18.Text = ":دستمزد کارگران ";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(202, 395);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 23);
            this.label17.TabIndex = 706;
            this.label17.Text = ":کرایه حمل";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(203, 367);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 20);
            this.label16.TabIndex = 705;
            this.label16.Text = ":تخفیف";
            // 
            // karmozdtxt
            // 
            this.karmozdtxt.Location = new System.Drawing.Point(42, 473);
            this.karmozdtxt.Multiline = true;
            this.karmozdtxt.Name = "karmozdtxt";
            this.karmozdtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.karmozdtxt.Size = new System.Drawing.Size(149, 24);
            this.karmozdtxt.TabIndex = 704;
            this.karmozdtxt.Text = "0";
            // 
            // maliayattxt
            // 
            this.maliayattxt.Location = new System.Drawing.Point(42, 445);
            this.maliayattxt.Multiline = true;
            this.maliayattxt.Name = "maliayattxt";
            this.maliayattxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maliayattxt.Size = new System.Drawing.Size(149, 24);
            this.maliayattxt.TabIndex = 703;
            this.maliayattxt.Text = "0";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label14.Location = new System.Drawing.Point(200, 331);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 23);
            this.label14.TabIndex = 702;
            this.label14.Text = ":جمع اقلام";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(746, 300);
            this.textBox20.Multiline = true;
            this.textBox20.Name = "textBox20";
            this.textBox20.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox20.Size = new System.Drawing.Size(37, 22);
            this.textBox20.TabIndex = 701;
            this.textBox20.Text = "5";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(746, 276);
            this.textBox21.Multiline = true;
            this.textBox21.Name = "textBox21";
            this.textBox21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox21.Size = new System.Drawing.Size(37, 22);
            this.textBox21.TabIndex = 700;
            this.textBox21.Text = "4";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(746, 252);
            this.textBox22.Multiline = true;
            this.textBox22.Name = "textBox22";
            this.textBox22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox22.Size = new System.Drawing.Size(37, 22);
            this.textBox22.TabIndex = 699;
            this.textBox22.Text = "3";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(746, 228);
            this.textBox23.Multiline = true;
            this.textBox23.Name = "textBox23";
            this.textBox23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox23.Size = new System.Drawing.Size(37, 22);
            this.textBox23.TabIndex = 698;
            this.textBox23.Text = "2";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(746, 204);
            this.textBox24.Multiline = true;
            this.textBox24.Name = "textBox24";
            this.textBox24.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox24.Size = new System.Drawing.Size(37, 22);
            this.textBox24.TabIndex = 697;
            this.textBox24.Text = "1";
            // 
            // gheimatkala5txt
            // 
            this.gheimatkala5txt.Location = new System.Drawing.Point(193, 300);
            this.gheimatkala5txt.Multiline = true;
            this.gheimatkala5txt.Name = "gheimatkala5txt";
            this.gheimatkala5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala5txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala5txt.TabIndex = 688;
            this.gheimatkala5txt.Text = "0";
            // 
            // gheimatkala4txt
            // 
            this.gheimatkala4txt.Location = new System.Drawing.Point(193, 276);
            this.gheimatkala4txt.Multiline = true;
            this.gheimatkala4txt.Name = "gheimatkala4txt";
            this.gheimatkala4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala4txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala4txt.TabIndex = 679;
            this.gheimatkala4txt.Text = "0";
            // 
            // gheimatkala3txt
            // 
            this.gheimatkala3txt.Location = new System.Drawing.Point(193, 252);
            this.gheimatkala3txt.Multiline = true;
            this.gheimatkala3txt.Name = "gheimatkala3txt";
            this.gheimatkala3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala3txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala3txt.TabIndex = 675;
            this.gheimatkala3txt.Text = "0";
            // 
            // gheimatkala2txt
            // 
            this.gheimatkala2txt.Location = new System.Drawing.Point(193, 228);
            this.gheimatkala2txt.Multiline = true;
            this.gheimatkala2txt.Name = "gheimatkala2txt";
            this.gheimatkala2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala2txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala2txt.TabIndex = 672;
            this.gheimatkala2txt.Text = "0";
            // 
            // gheimatkala1txt
            // 
            this.gheimatkala1txt.Location = new System.Drawing.Point(193, 204);
            this.gheimatkala1txt.Multiline = true;
            this.gheimatkala1txt.Name = "gheimatkala1txt";
            this.gheimatkala1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala1txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala1txt.TabIndex = 669;
            this.gheimatkala1txt.Text = "0";
            this.gheimatkala1txt.TextChanged += new System.EventHandler(this.gheimatkala1txt_TextChanged);
            // 
            // tedadkala5nud
            // 
            this.tedadkala5nud.AutoSize = true;
            this.tedadkala5nud.Location = new System.Drawing.Point(396, 300);
            this.tedadkala5nud.Name = "tedadkala5nud";
            this.tedadkala5nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala5nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala5nud.TabIndex = 687;
            // 
            // tedadkala4nud
            // 
            this.tedadkala4nud.AutoSize = true;
            this.tedadkala4nud.Location = new System.Drawing.Point(396, 276);
            this.tedadkala4nud.Name = "tedadkala4nud";
            this.tedadkala4nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala4nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala4nud.TabIndex = 678;
            // 
            // tedadkala3nud
            // 
            this.tedadkala3nud.AutoSize = true;
            this.tedadkala3nud.Location = new System.Drawing.Point(396, 252);
            this.tedadkala3nud.Name = "tedadkala3nud";
            this.tedadkala3nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala3nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala3nud.TabIndex = 674;
            // 
            // tedadkala2nud
            // 
            this.tedadkala2nud.AutoSize = true;
            this.tedadkala2nud.Location = new System.Drawing.Point(396, 228);
            this.tedadkala2nud.Name = "tedadkala2nud";
            this.tedadkala2nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala2nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala2nud.TabIndex = 671;
            // 
            // tedadkala1nud
            // 
            this.tedadkala1nud.AutoSize = true;
            this.tedadkala1nud.Location = new System.Drawing.Point(396, 205);
            this.tedadkala1nud.Name = "tedadkala1nud";
            this.tedadkala1nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala1nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala1nud.TabIndex = 668;
            // 
            // namekala5cmb
            // 
            this.namekala5cmb.FormattingEnabled = true;
            this.namekala5cmb.Items.AddRange(new object[] {
            ""});
            this.namekala5cmb.Location = new System.Drawing.Point(453, 300);
            this.namekala5cmb.Name = "namekala5cmb";
            this.namekala5cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala5cmb.Size = new System.Drawing.Size(113, 21);
            this.namekala5cmb.TabIndex = 686;
            // 
            // namekala4cmb
            // 
            this.namekala4cmb.FormattingEnabled = true;
            this.namekala4cmb.Items.AddRange(new object[] {
            ""});
            this.namekala4cmb.Location = new System.Drawing.Point(452, 276);
            this.namekala4cmb.Name = "namekala4cmb";
            this.namekala4cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala4cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala4cmb.TabIndex = 676;
            // 
            // namekala3cmb
            // 
            this.namekala3cmb.FormattingEnabled = true;
            this.namekala3cmb.Items.AddRange(new object[] {
            ""});
            this.namekala3cmb.Location = new System.Drawing.Point(452, 252);
            this.namekala3cmb.Name = "namekala3cmb";
            this.namekala3cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala3cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala3cmb.TabIndex = 673;
            // 
            // namekala2cmb
            // 
            this.namekala2cmb.FormattingEnabled = true;
            this.namekala2cmb.Items.AddRange(new object[] {
            ""});
            this.namekala2cmb.Location = new System.Drawing.Point(452, 228);
            this.namekala2cmb.Name = "namekala2cmb";
            this.namekala2cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala2cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala2cmb.TabIndex = 670;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label37.Location = new System.Drawing.Point(66, 178);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(99, 23);
            this.label37.TabIndex = 696;
            this.label37.Text = "جمع ";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label36.Location = new System.Drawing.Point(208, 177);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(108, 23);
            this.label36.TabIndex = 695;
            this.label36.Text = "قیمت واحد";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label33.Location = new System.Drawing.Point(335, 177);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(54, 23);
            this.label33.TabIndex = 694;
            this.label33.Text = "واحد کالا";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label32.Location = new System.Drawing.Point(398, 177);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(50, 23);
            this.label32.TabIndex = 693;
            this.label32.Text = "تعداد";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label31.Location = new System.Drawing.Point(453, 178);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(113, 23);
            this.label31.TabIndex = 692;
            this.label31.Text = "نام کالا";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // namekala1cmb
            // 
            this.namekala1cmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namekala1cmb.FormattingEnabled = true;
            this.namekala1cmb.Items.AddRange(new object[] {
            ""});
            this.namekala1cmb.Location = new System.Drawing.Point(452, 204);
            this.namekala1cmb.Name = "namekala1cmb";
            this.namekala1cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala1cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala1cmb.TabIndex = 667;
            this.namekala1cmb.SelectedIndexChanged += new System.EventHandler(this.namekala1cmb_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label6.Location = new System.Drawing.Point(746, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 23);
            this.label6.TabIndex = 691;
            this.label6.Text = "ردیف";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape11,
            this.lineShape10,
            this.lineShape9,
            this.lineShape8,
            this.rectangleShape4,
            this.rectangleShape3,
            this.rectangleShape2,
            this.lineShape7,
            this.lineShape6,
            this.lineShape5,
            this.lineShape4,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(793, 553);
            this.shapeContainer1.TabIndex = 749;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape11
            // 
            this.lineShape11.Name = "lineShape11";
            this.lineShape11.X1 = 38;
            this.lineShape11.X2 = 783;
            this.lineShape11.Y1 = 228;
            this.lineShape11.Y2 = 227;
            // 
            // lineShape10
            // 
            this.lineShape10.Name = "lineShape10";
            this.lineShape10.X1 = 39;
            this.lineShape10.X2 = 784;
            this.lineShape10.Y1 = 202;
            this.lineShape10.Y2 = 201;
            // 
            // lineShape9
            // 
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 247;
            this.lineShape9.X2 = 618;
            this.lineShape9.Y1 = 148;
            this.lineShape9.Y2 = 148;
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 413;
            this.lineShape8.X2 = 413;
            this.lineShape8.Y1 = 119;
            this.lineShape8.Y2 = 174;
            // 
            // rectangleShape4
            // 
            this.rectangleShape4.Location = new System.Drawing.Point(246, 119);
            this.rectangleShape4.Name = "rectangleShape4";
            this.rectangleShape4.Size = new System.Drawing.Size(372, 54);
            // 
            // rectangleShape3
            // 
            this.rectangleShape3.Location = new System.Drawing.Point(39, 362);
            this.rectangleShape3.Name = "rectangleShape3";
            this.rectangleShape3.Size = new System.Drawing.Size(287, 167);
            // 
            // rectangleShape2
            // 
            this.rectangleShape2.Location = new System.Drawing.Point(567, 362);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new System.Drawing.Size(218, 29);
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 687;
            this.lineShape7.X2 = 686;
            this.lineShape7.Y1 = 175;
            this.lineShape7.Y2 = 360;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 192;
            this.lineShape6.X2 = 191;
            this.lineShape6.Y1 = 175;
            this.lineShape6.Y2 = 360;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 327;
            this.lineShape5.X2 = 326;
            this.lineShape5.Y1 = 175;
            this.lineShape5.Y2 = 360;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 567;
            this.lineShape4.X2 = 566;
            this.lineShape4.Y1 = 175;
            this.lineShape4.Y2 = 360;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 450;
            this.lineShape3.X2 = 449;
            this.lineShape3.Y1 = 175;
            this.lineShape3.Y2 = 360;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 395;
            this.lineShape2.X2 = 394;
            this.lineShape2.Y1 = 175;
            this.lineShape2.Y2 = 360;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 745;
            this.lineShape1.X2 = 744;
            this.lineShape1.Y1 = 175;
            this.lineShape1.Y2 = 360;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.Location = new System.Drawing.Point(39, 174);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(746, 187);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::projemasaleh.Properties.Resources.Cancel_Big;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(7, 8);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(31, 28);
            this.enserafbtn.TabIndex = 721;
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::projemasaleh.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(106, 8);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 720;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // AddFactor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(793, 553);
            this.Controls.Add(this.kerayehamltxt);
            this.Controls.Add(this.id5txt);
            this.Controls.Add(this.id4txt);
            this.Controls.Add(this.id3txt);
            this.Controls.Add(this.id2txt);
            this.Controls.Add(this.id1txt);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.barcode5txt);
            this.Controls.Add(this.barcode4txt);
            this.Controls.Add(this.barcode3txt);
            this.Controls.Add(this.barcode2txt);
            this.Controls.Add(this.barcode1txt);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.vahedkala5txt);
            this.Controls.Add(this.vahedkala4txt);
            this.Controls.Add(this.vahedkala3txt);
            this.Controls.Add(this.vahedkala2txt);
            this.Controls.Add(this.vahedkala1txt);
            this.Controls.Add(this.gheimateaghlam);
            this.Controls.Add(this.gheimateradif5txt);
            this.Controls.Add(this.gheimateradif4txt);
            this.Controls.Add(this.gheimateradif3txt);
            this.Controls.Add(this.gheimateradif2txt);
            this.Controls.Add(this.gheimateradif1txt);
            this.Controls.Add(this.dastmozdekargartxt);
            this.Controls.Add(this.takhfiftxt);
            this.Controls.Add(this.gheimatekoltxt);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.nameranandetxt);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.namemoshtaricmb);
            this.Controls.Add(this.idmoshtaritxt);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tarikhmtxt);
            this.Controls.Add(this.lblkarbar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.idfactortxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.darsadkarmozdtxt);
            this.Controls.Add(this.darsadmaliyattxt);
            this.Controls.Add(this.darsadetakhfiftxt);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.karmozdtxt);
            this.Controls.Add(this.maliayattxt);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.gheimatkala5txt);
            this.Controls.Add(this.gheimatkala4txt);
            this.Controls.Add(this.gheimatkala3txt);
            this.Controls.Add(this.gheimatkala2txt);
            this.Controls.Add(this.gheimatkala1txt);
            this.Controls.Add(this.tedadkala5nud);
            this.Controls.Add(this.tedadkala4nud);
            this.Controls.Add(this.tedadkala3nud);
            this.Controls.Add(this.tedadkala2nud);
            this.Controls.Add(this.tedadkala1nud);
            this.Controls.Add(this.namekala5cmb);
            this.Controls.Add(this.namekala4cmb);
            this.Controls.Add(this.namekala3cmb);
            this.Controls.Add(this.namekala2cmb);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.namekala1cmb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "AddFactor";
            this.Text = "فاکتور فروش";
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala5nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala4nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala3nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala2nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala1nud)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox kerayehamltxt;
        private System.Windows.Forms.TextBox id5txt;
        private System.Windows.Forms.TextBox id4txt;
        private System.Windows.Forms.TextBox id3txt;
        private System.Windows.Forms.TextBox id2txt;
        private System.Windows.Forms.TextBox id1txt;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox barcode5txt;
        private System.Windows.Forms.TextBox barcode4txt;
        private System.Windows.Forms.TextBox barcode3txt;
        private System.Windows.Forms.TextBox barcode2txt;
        private System.Windows.Forms.TextBox barcode1txt;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox vahedkala5txt;
        private System.Windows.Forms.TextBox vahedkala4txt;
        private System.Windows.Forms.TextBox vahedkala3txt;
        private System.Windows.Forms.TextBox vahedkala2txt;
        private System.Windows.Forms.TextBox vahedkala1txt;
        private System.Windows.Forms.TextBox gheimateaghlam;
        private System.Windows.Forms.TextBox gheimateradif5txt;
        private System.Windows.Forms.TextBox gheimateradif4txt;
        private System.Windows.Forms.TextBox gheimateradif3txt;
        private System.Windows.Forms.TextBox gheimateradif2txt;
        private System.Windows.Forms.TextBox gheimateradif1txt;
        private System.Windows.Forms.TextBox dastmozdekargartxt;
        private System.Windows.Forms.TextBox takhfiftxt;
        private System.Windows.Forms.TextBox gheimatekoltxt;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.TextBox nameranandetxt;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox namemoshtaricmb;
        private System.Windows.Forms.TextBox idmoshtaritxt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox tarikhmtxt;
        private System.Windows.Forms.Label lblkarbar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox idfactortxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox darsadkarmozdtxt;
        private System.Windows.Forms.TextBox darsadmaliyattxt;
        private System.Windows.Forms.TextBox darsadetakhfiftxt;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox karmozdtxt;
        private System.Windows.Forms.TextBox maliayattxt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox gheimatkala5txt;
        private System.Windows.Forms.TextBox gheimatkala4txt;
        private System.Windows.Forms.TextBox gheimatkala3txt;
        private System.Windows.Forms.TextBox gheimatkala2txt;
        private System.Windows.Forms.TextBox gheimatkala1txt;
        private System.Windows.Forms.NumericUpDown tedadkala5nud;
        private System.Windows.Forms.NumericUpDown tedadkala4nud;
        private System.Windows.Forms.NumericUpDown tedadkala3nud;
        private System.Windows.Forms.NumericUpDown tedadkala2nud;
        private System.Windows.Forms.NumericUpDown tedadkala1nud;
        private System.Windows.Forms.ComboBox namekala5cmb;
        private System.Windows.Forms.ComboBox namekala4cmb;
        private System.Windows.Forms.ComboBox namekala3cmb;
        private System.Windows.Forms.ComboBox namekala2cmb;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox namekala1cmb;
        private System.Windows.Forms.Label label6;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape11;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape10;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape9;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape4;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape3;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
    }
}

