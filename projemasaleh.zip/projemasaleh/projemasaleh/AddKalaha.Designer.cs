﻿namespace projemasaleh
{
    partial class AddKalaha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.namesherkattxt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tarikhenghezamtxt = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.namekalatxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tarikhtolidmtxt = new System.Windows.Forms.MaskedTextBox();
            this.modeltxt = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.garantytxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.hadeaghaletedadmojodmtxt = new System.Windows.Forms.MaskedTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.idkalakhfmtxt = new System.Windows.Forms.MaskedTextBox();
            this.tedadekalamtxt = new System.Windows.Forms.MaskedTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.vahedfareetxt = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.vahedaslitxt = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tozihattxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gheimatforoshmtxt = new System.Windows.Forms.MaskedTextBox();
            this.barcodemtxt = new System.Windows.Forms.MaskedTextBox();
            this.gheimatekharidmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // namesherkattxt
            // 
            this.namesherkattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namesherkattxt.Location = new System.Drawing.Point(29, 240);
            this.namesherkattxt.Name = "namesherkattxt";
            this.namesherkattxt.Size = new System.Drawing.Size(116, 20);
            this.namesherkattxt.TabIndex = 15;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(260, 137);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 23);
            this.label13.TabIndex = 52;
            this.label13.Text = "*";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(400, 137);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 23);
            this.label14.TabIndex = 50;
            this.label14.Text = "قیمت خرید:";
            // 
            // tarikhenghezamtxt
            // 
            this.tarikhenghezamtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhenghezamtxt.Location = new System.Drawing.Point(29, 101);
            this.tarikhenghezamtxt.Mask = "9999/99/99";
            this.tarikhenghezamtxt.Name = "tarikhenghezamtxt";
            this.tarikhenghezamtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhenghezamtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhenghezamtxt.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(152, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 23);
            this.label9.TabIndex = 48;
            this.label9.Text = "تاریخ انقضا:";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(260, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 23);
            this.label4.TabIndex = 47;
            this.label4.Text = "*";
            // 
            // namekalatxt
            // 
            this.namekalatxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namekalatxt.Location = new System.Drawing.Point(277, 68);
            this.namekalatxt.Name = "namekalatxt";
            this.namekalatxt.Size = new System.Drawing.Size(116, 20);
            this.namekalatxt.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(12, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 45;
            this.label5.Text = "*";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(149, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 23);
            this.label3.TabIndex = 43;
            this.label3.Text = "حداقل تعداد موجود:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(397, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 23);
            this.label2.TabIndex = 42;
            this.label2.Text = "نام کالا:";
            // 
            // tarikhtolidmtxt
            // 
            this.tarikhtolidmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhtolidmtxt.Location = new System.Drawing.Point(277, 101);
            this.tarikhtolidmtxt.Mask = "9999/99/99";
            this.tarikhtolidmtxt.Name = "tarikhtolidmtxt";
            this.tarikhtolidmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhtolidmtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhtolidmtxt.TabIndex = 7;
            // 
            // modeltxt
            // 
            this.modeltxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.modeltxt.Location = new System.Drawing.Point(277, 241);
            this.modeltxt.Name = "modeltxt";
            this.modeltxt.Size = new System.Drawing.Size(116, 20);
            this.modeltxt.TabIndex = 14;
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(399, 242);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 23);
            this.label21.TabIndex = 33;
            this.label21.Text = "مدل کالا:";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(260, 209);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 23);
            this.label11.TabIndex = 9;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(393, 207);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 23);
            this.label12.TabIndex = 7;
            this.label12.Text = "تعداد کالا:";
            // 
            // garantytxt
            // 
            this.garantytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.garantytxt.Location = new System.Drawing.Point(29, 170);
            this.garantytxt.Name = "garantytxt";
            this.garantytxt.Size = new System.Drawing.Size(364, 20);
            this.garantytxt.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(394, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 23);
            this.label7.TabIndex = 2;
            this.label7.Text = "گارانتی:";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(398, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 23);
            this.label8.TabIndex = 1;
            this.label8.Text = "تاریخ تولید:";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(145, 207);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 23);
            this.label18.TabIndex = 56;
            this.label18.Text = "بارکد کالا:";
            // 
            // hadeaghaletedadmojodmtxt
            // 
            this.hadeaghaletedadmojodmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hadeaghaletedadmojodmtxt.Location = new System.Drawing.Point(29, 68);
            this.hadeaghaletedadmojodmtxt.Name = "hadeaghaletedadmojodmtxt";
            this.hadeaghaletedadmojodmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hadeaghaletedadmojodmtxt.Size = new System.Drawing.Size(116, 20);
            this.hadeaghaletedadmojodmtxt.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.hadeaghaletedadmojodmtxt);
            this.groupBox2.Controls.Add(this.idkalakhfmtxt);
            this.groupBox2.Controls.Add(this.tedadekalamtxt);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.namesherkattxt);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.tozihattxt);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.gheimatforoshmtxt);
            this.groupBox2.Controls.Add(this.barcodemtxt);
            this.groupBox2.Controls.Add(this.gheimatekharidmtxt);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.tarikhenghezamtxt);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.namekalatxt);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tarikhtolidmtxt);
            this.groupBox2.Controls.Add(this.modeltxt);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.garantytxt);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(8, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(487, 433);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            // 
            // idkalakhfmtxt
            // 
            this.idkalakhfmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idkalakhfmtxt.Location = new System.Drawing.Point(211, 32);
            this.idkalakhfmtxt.Name = "idkalakhfmtxt";
            this.idkalakhfmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idkalakhfmtxt.Size = new System.Drawing.Size(116, 20);
            this.idkalakhfmtxt.TabIndex = 4;
            // 
            // tedadekalamtxt
            // 
            this.tedadekalamtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tedadekalamtxt.Location = new System.Drawing.Point(277, 205);
            this.tedadekalamtxt.Name = "tedadekalamtxt";
            this.tedadekalamtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadekalamtxt.Size = new System.Drawing.Size(116, 20);
            this.tedadekalamtxt.TabIndex = 12;
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label31.ForeColor = System.Drawing.Color.Red;
            this.label31.Location = new System.Drawing.Point(197, 37);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(16, 23);
            this.label31.TabIndex = 68;
            this.label31.Text = "*";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.vahedfareetxt);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.vahedaslitxt);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Location = new System.Drawing.Point(15, 338);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(457, 72);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "واحد شمارش کالا";
            // 
            // vahedfareetxt
            // 
            this.vahedfareetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vahedfareetxt.Location = new System.Drawing.Point(14, 28);
            this.vahedfareetxt.Name = "vahedfareetxt";
            this.vahedfareetxt.Size = new System.Drawing.Size(104, 20);
            this.vahedfareetxt.TabIndex = 18;
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(117, 31);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(111, 23);
            this.label28.TabIndex = 72;
            this.label28.Text = "واحد شمارش فرعی:";
            // 
            // vahedaslitxt
            // 
            this.vahedaslitxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vahedaslitxt.Location = new System.Drawing.Point(241, 29);
            this.vahedaslitxt.Name = "vahedaslitxt";
            this.vahedaslitxt.Size = new System.Drawing.Size(104, 20);
            this.vahedaslitxt.TabIndex = 17;
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(352, 30);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 23);
            this.label25.TabIndex = 70;
            this.label25.Text = "واحد شمارش اصلی:";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(153, 241);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(109, 23);
            this.label20.TabIndex = 65;
            this.label20.Text = "نام شرکت تولید کننده:";
            // 
            // tozihattxt
            // 
            this.tozihattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tozihattxt.Location = new System.Drawing.Point(29, 277);
            this.tozihattxt.Multiline = true;
            this.tozihattxt.Name = "tozihattxt";
            this.tozihattxt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tozihattxt.Size = new System.Drawing.Size(364, 46);
            this.tozihattxt.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(338, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 23);
            this.label10.TabIndex = 19;
            this.label10.Text = "کد کالای خرید و فروش:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(396, 278);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 23);
            this.label1.TabIndex = 63;
            this.label1.Text = "توضیحات:";
            // 
            // gheimatforoshmtxt
            // 
            this.gheimatforoshmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatforoshmtxt.Location = new System.Drawing.Point(29, 135);
            this.gheimatforoshmtxt.Name = "gheimatforoshmtxt";
            this.gheimatforoshmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatforoshmtxt.Size = new System.Drawing.Size(116, 20);
            this.gheimatforoshmtxt.TabIndex = 10;
            // 
            // barcodemtxt
            // 
            this.barcodemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.barcodemtxt.Location = new System.Drawing.Point(29, 205);
            this.barcodemtxt.Mask = "9999999999999";
            this.barcodemtxt.Name = "barcodemtxt";
            this.barcodemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcodemtxt.Size = new System.Drawing.Size(116, 20);
            this.barcodemtxt.TabIndex = 13;
            // 
            // gheimatekharidmtxt
            // 
            this.gheimatekharidmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatekharidmtxt.Location = new System.Drawing.Point(277, 136);
            this.gheimatekharidmtxt.Name = "gheimatekharidmtxt";
            this.gheimatekharidmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatekharidmtxt.Size = new System.Drawing.Size(116, 20);
            this.gheimatekharidmtxt.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(12, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 23);
            this.label15.TabIndex = 55;
            this.label15.Text = "*";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(148, 137);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 23);
            this.label16.TabIndex = 53;
            this.label16.Text = "قیمت فروش:";
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::projemasaleh.Properties.Resources.save_16x162;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(252, 465);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 26;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::projemasaleh.Properties.Resources.cross_script1;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(157, 465);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 27;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // AddKalaha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(503, 519);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.groupBox2);
            this.Name = "AddKalaha";
            this.Text = "کالاها";
            this.Load += new System.EventHandler(this.AddKalaha_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox namesherkattxt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox tarikhenghezamtxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox namekalatxt;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox tarikhtolidmtxt;
        private System.Windows.Forms.TextBox modeltxt;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.TextBox garantytxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.MaskedTextBox hadeaghaletedadmojodmtxt;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MaskedTextBox idkalakhfmtxt;
        private System.Windows.Forms.MaskedTextBox tedadekalamtxt;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox vahedfareetxt;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox vahedaslitxt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tozihattxt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox gheimatforoshmtxt;
        private System.Windows.Forms.MaskedTextBox barcodemtxt;
        private System.Windows.Forms.MaskedTextBox gheimatekharidmtxt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
    }
}