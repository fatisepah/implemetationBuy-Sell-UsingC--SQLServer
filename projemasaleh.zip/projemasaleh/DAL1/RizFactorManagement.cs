﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL1
{
    public class RizFactorManagement : SqlClass
    {
        linqDataContext obj = new linqDataContext();
        protected void RizFactorKharidForoshInsert2(RizFactorDB db)
        {
            obj.RizFactorKharidForoshInsert(db.IDFactorKHF, db.NameKalayeKharidForosh1, db.Tedade1, db.NameKalayeKharidForosh2, db.Tedade2, db.NameKalayeKharidForosh3, db.Tedade3, db.NameKalayeKharidForosh4, db.Tedade4, db.NameKalayeKharidForosh5, db.Tedade5, db.FKFactor, db.GheimateKol);
        }
        protected Boolean RizFactorKharidForoshSearch2(int IDFactorKHF)
        {
            string str = string.Format("SELECT * FROM TblRizFactor Where IDFactorKHF= '{0}'", IDFactorKHF);
            return find_row(str);
        }
        protected void RizFactorKharidForoshDelete2(int IDFactorKHF,int FKFactor)
        {
            obj.RizFactorKharidForoshDelete(IDFactorKHF, FKFactor);
        }
        protected void RizFactorKharidForoshUpdate2(RizFactorDB db)
        {
            obj.RizFactorKharidForoshUpdate(db.IDFactorKHF, db.NameKalayeKharidForosh1, db.Tedade1, db.NameKalayeKharidForosh2, db.Tedade2, db.NameKalayeKharidForosh3, db.Tedade3, db.NameKalayeKharidForosh4, db.Tedade4, db.NameKalayeKharidForosh5, db.Tedade5, db.FKFactor, db.GheimateKol);

        }
    }
}