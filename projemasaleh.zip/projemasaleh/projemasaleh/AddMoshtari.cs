﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL1;
using BLL;

namespace projemasaleh
{
    public partial class AddMoshtari : Form
    {
        public AddMoshtari()
        {
            InitializeComponent();
        }
        MoshtariDB DBMoshtari = new MoshtariDB();
        MoshtariData objMoshtari = new MoshtariData();
        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idmoshtaritxt.Text != "" && namemoshtaritxt.Text != "")
            {
                DBMoshtari.IDMoshtari = Convert.ToInt32(idmoshtaritxt.Text);
                DBMoshtari.NameMoshtari = namemoshtaritxt.Text;
                DBMoshtari.Mobile = mobilemtxt.Text;
                DBMoshtari.AddressKhane = addresskhanetxt.Text;
                DBMoshtari.AddressKar = addresskartxt.Text;
                DBMoshtari.Email = emailmoshtaritxt.Text;
                if (Class1.virayesh != 0)
                {

                    objMoshtari.MoshtariUpdate1(DBMoshtari);
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    Class1.virayesh = 0;
                    Class1.IDMoshtari = Convert.ToInt32(idmoshtaritxt.Text);
                    idmoshtaritxt.Text = "";
                    namemoshtaritxt.Text = "";
                    mobilemtxt.Text = "";
                    addresskhanetxt.Text = "";
                    addresskartxt.Text = "";
                    emailmoshtaritxt.Text = "";
                }
                //اگر کد مشتری و حساب بانکی که برای آنها وارد شده رو پیدا نکرد درج انجام شود
                else
                {
                    if (!objMoshtari.MoshtariSearch1(DBMoshtari.IDMoshtari))
                    {

                        objMoshtari.MoshtariInsert1(DBMoshtari);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDMoshtari= Convert.ToInt32(idmoshtaritxt .Text);
                            idmoshtaritxt.Text = "";
                            namemoshtaritxt.Text = "";
                            mobilemtxt.Text = "";
                            addresskhanetxt.Text = "";
                            addresskartxt.Text = "";
                            emailmoshtaritxt.Text = "";
                        }
                        Close();


                    }
                    else
                    {
                        MessageBox.Show("کد مشتری تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AddMoshtari_Load(object sender, EventArgs e)
        {
            int i1 = 0;
            int i2 = 1;
            if (Class1.virayesh != 0)
            {
                DBMoshtari = objMoshtari.MoshtariFind1 (Class1.virayesh);
                idmoshtaritxt .Text = DBMoshtari.IDMoshtari.ToString();
                namemoshtaritxt .Text = DBMoshtari.NameMoshtari;
                mobilemtxt .Text = DBMoshtari.Mobile;
                addresskhanetxt .Text = DBMoshtari.AddressKhane ;
                addresskartxt .Text = DBMoshtari.AddressKar .ToString();
                emailmoshtaritxt .Text = DBMoshtari.Email .ToString();
            }
            else
            {
                DataTable dt = objMoshtari.MoshtariSearchID1 ();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idmoshtaritxt .Text = "1";
                }
                else
                {
                    idmoshtaritxt .Text = Convert.ToString(i2 + 1);
                }

            }
        }
    }
}
