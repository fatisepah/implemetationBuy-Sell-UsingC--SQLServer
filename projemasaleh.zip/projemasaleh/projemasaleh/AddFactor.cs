﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL1;
using BLL;

namespace projemasaleh
{
    public partial class AddFactor : Form
    {
        public AddFactor()
        {
            InitializeComponent();
        }
        FactorData FData = new FactorData();
        FactorDB FDB = new FactorDB();
        //
        RizFactorData RFKFData = new RizFactorData();
        RizFactorDB RFKFDB = new RizFactorDB();
        //

        MoshtariData MData = new MoshtariData();
        MoshtariDB MDB = new MoshtariDB();
        //
        KalaData KKFData = new KalaData();
        KalaDB KKFDB = new KalaDB();
        //
        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idfactortxt.Text != "" )
            {
                //برای جدول فاکتور
                FDB.IDFactor = Convert.ToInt32(idfactortxt.Text);
                FDB.FKMoshtari = Convert.ToInt32(idmoshtaritxt.Text);
                FDB.NameMoshtari = namemoshtaricmb.Text;
                FDB.NameKarbar = lblkarbar.Text;
                FDB.TarikheFactor = tarikhmtxt.Text;
                FDB.DarsadeTakhfif = darsadetakhfiftxt.Text;
                FDB.NameRanande = nameranandetxt.Text;
                FDB.DastMozdeKargareBarbari = Convert.ToInt64(dastmozdekargartxt.Text);
                FDB.KerayeHaml = Convert.ToInt64(kerayehamltxt.Text);
                //برای جدول ریز فاکتور
                RFKFDB.IDFactorKHF = Convert.ToInt32(idfactortxt.Text);
                RFKFDB.NameKalayeKharidForosh1 = namekala1cmb.Text;
                RFKFDB.Tedade1 = Convert.ToInt32(tedadkala1nud.Value);
                RFKFDB.NameKalayeKharidForosh2 = namekala2cmb.Text;
                RFKFDB.Tedade2 = Convert.ToInt32(tedadkala2nud.Value);
                RFKFDB.NameKalayeKharidForosh3 = namekala3cmb.Text;
                RFKFDB.Tedade3 = Convert.ToInt32(tedadkala3nud.Text);
                RFKFDB.NameKalayeKharidForosh4 = namekala4cmb.Text;
                RFKFDB.Tedade4 = Convert.ToInt32(tedadkala4nud.Text);
                RFKFDB.NameKalayeKharidForosh5 = namekala5cmb.Text;
                RFKFDB.Tedade5 = Convert.ToInt32(tedadkala5nud.Text);
                RFKFDB.FKFactor = Convert.ToInt32(idfactortxt.Text);
                RFKFDB.GheimateKol = Convert.ToInt64(gheimatekoltxt.Text);




                if (!RFKFData.RizFactorKharidForoshSearch1(RFKFDB.IDFactorKHF) && !FData.FactorSearch1(FDB.IDFactor))
                {
                    FData.FactorInsert1(FDB);
                    RFKFData.RizFactorKharidForoshInsert1(RFKFDB);
                    if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                    }
                    Close();
                }
                else
                {
                    MessageBox.Show("کد فاکتور تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void namekala1cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //DataTable DT = MData.MoshtariComboShow1();
            //for (int i = 0; i < DT.Rows.Count; i++)
            //{
            //    int IDMoshtari = Convert.ToInt32(DT.Rows[i][0].ToString());
            //    string NameMoshtari = DT.Rows[i][1].ToString();


            //    ListItem item = new ListItem();
            //    item.Text = NameMoshtari;
            //    item.Value = IDMoshtari.ToString();
            //    if (namemoshtaricmb.Text == item.Text)
            //    {
            //        idmoshtaritxt.Text = IDMoshtari.ToString();
            //        break;
            //    }

            //}
        }

        private void gheimatkala1txt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
