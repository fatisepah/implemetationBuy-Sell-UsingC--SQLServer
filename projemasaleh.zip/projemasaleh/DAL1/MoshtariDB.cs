﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL1
{
    public class MoshtariDB
    {
        public int IDMoshtari { set; get; }
        public string NameMoshtari { set; get; }
        public string Mobile { set; get; }
        public string AddressKhane { set; get; }
        public string AddressKar { set; get; }
        public string Email { set; get; }


    }
}
