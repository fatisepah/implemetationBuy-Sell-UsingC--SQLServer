﻿namespace projemasaleh
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.فاکتورهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فاکتورخریدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فاکتورفروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.تعاریفپایهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.کابرانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مشتریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لوازمساختمانیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // فاکتورهاToolStripMenuItem
            // 
            this.فاکتورهاToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.فاکتورخریدToolStripMenuItem,
            this.فاکتورفروشToolStripMenuItem});
            this.فاکتورهاToolStripMenuItem.Name = "فاکتورهاToolStripMenuItem";
            this.فاکتورهاToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.فاکتورهاToolStripMenuItem.Text = "فاکتورها";
            // 
            // فاکتورخریدToolStripMenuItem
            // 
            this.فاکتورخریدToolStripMenuItem.Name = "فاکتورخریدToolStripMenuItem";
            this.فاکتورخریدToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.فاکتورخریدToolStripMenuItem.Text = "فاکتور خرید";
            this.فاکتورخریدToolStripMenuItem.Click += new System.EventHandler(this.فاکتورخریدToolStripMenuItem_Click);
            // 
            // فاکتورفروشToolStripMenuItem
            // 
            this.فاکتورفروشToolStripMenuItem.Name = "فاکتورفروشToolStripMenuItem";
            this.فاکتورفروشToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.فاکتورفروشToolStripMenuItem.Text = "فاکتور فروش";
            this.فاکتورفروشToolStripMenuItem.Click += new System.EventHandler(this.فاکتورفروشToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تعاریفپایهToolStripMenuItem,
            this.فاکتورهاToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(769, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // تعاریفپایهToolStripMenuItem
            // 
            this.تعاریفپایهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.کابرانToolStripMenuItem,
            this.مشتریToolStripMenuItem,
            this.لوازمساختمانیToolStripMenuItem});
            this.تعاریفپایهToolStripMenuItem.Name = "تعاریفپایهToolStripMenuItem";
            this.تعاریفپایهToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.تعاریفپایهToolStripMenuItem.Text = "تعاریف پایه";
            // 
            // کابرانToolStripMenuItem
            // 
            this.کابرانToolStripMenuItem.Name = "کابرانToolStripMenuItem";
            this.کابرانToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.کابرانToolStripMenuItem.Text = "کاربران";
            this.کابرانToolStripMenuItem.Click += new System.EventHandler(this.کابرانToolStripMenuItem_Click);
            // 
            // مشتریToolStripMenuItem
            // 
            this.مشتریToolStripMenuItem.Name = "مشتریToolStripMenuItem";
            this.مشتریToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.مشتریToolStripMenuItem.Text = "مشتری";
            this.مشتریToolStripMenuItem.Click += new System.EventHandler(this.مشتریToolStripMenuItem_Click);
            // 
            // لوازمساختمانیToolStripMenuItem
            // 
            this.لوازمساختمانیToolStripMenuItem.Name = "لوازمساختمانیToolStripMenuItem";
            this.لوازمساختمانیToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.لوازمساختمانیToolStripMenuItem.Text = "لوازم ساختمانی";
            this.لوازمساختمانیToolStripMenuItem.Click += new System.EventHandler(this.لوازمساختمانیToolStripMenuItem_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(769, 471);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Main";
            this.Text = "فرم اصلی";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem فاکتورهاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فاکتورخریدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فاکتورفروشToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem تعاریفپایهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کابرانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مشتریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لوازمساختمانیToolStripMenuItem;
    }
}